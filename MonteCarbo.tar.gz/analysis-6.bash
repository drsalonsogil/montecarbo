#!/bin/bash
for i in {1..CALCS}
do
tac $i/calc$i.gjf.out | grep -m 1 "Qrad" >> Qrad.dat
tac $i/calc$i.gjf.out | grep -m 1 "PHI" >> PHI.dat
tac $i/calc$i.gjf.out | grep -m 1 "THETA" >> THETA.dat
tac $i/calc$i.gjf.out | grep -m 1 "SCF Done" >> Energy.dat
done
awk '{print $4}' Qrad.dat > Qrad
awk '{print $4}' PHI.dat > PHI
awk '{print $4}' THETA.dat > THETA
awk '{print $5}' Energy.dat > ENERGY
paste Qrad PHI THETA ENERGY > Results.dat

rm Qrad.dat PHI.dat THETA.dat Energy.dat Qrad PHI THETA ENERGY
