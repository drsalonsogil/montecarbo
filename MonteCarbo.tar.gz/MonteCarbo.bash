#!/bin/bash
FOLDER=${PWD}
echo "Welcome, what is the name of your project?"
read name
echo "Which kind of study do you want to perform?"
echo "PUCK - Find for minima in the puckering coordinate PES - Needs Gaussian 16"
echo "NOPUCKG, NOPUCKPDB, NOPUCKXYZ - The program generates structures for Gaussian16(G) or in PDB or XYZ formats (Babel required)"
echo "RIGID - Optimization with Gaussian16 keeping fixed the conformation of the ring (recommended for docking)"
read study
echo "How many atoms in the ring?"
read N
echo "How many heteroatoms in the ring?"
read H
hatom=0
if [ $H = 1 ]
then
  echo "Which heteroatom? (Oxy=oxygen,B=boron,N=nitrogen,P=phosphorus,S=sulfur,SO2=sulfoxide)"
  read hatom
  cp N-$N-H-$H-$hatom.zmat calc.zmat
  cp N-$N-H-$H-$hatom.var calc.var
  POSIC=$N
  NUMRAN=$(($N-3))
  if [ $hatom = "SO2" ]
  then
    POSIC=$(($POSIC+2))
  elif [ $hatom = "N" ] || [ $hatom = "P" ]
  then
    POSIC=$(($POSIC+1))
    NUMRAN=$(($NUMRAN+1))
  elif [ $hatom = "B" ]
  then
    POSIC=$(($POSIC+1))
  fi
else
  POSIC=$N
  NUMRAN=$(($N-3))
  cp N-$N-H-$H.zmat calc.zmat
  cp N-$N-H-$H.var calc.var
fi

bNAc=false
bOH=false
bCH3=false
bOCH3=false
bCH2OH=false
bCH2OCH3=false
bNH2=false
bAde=false
bThy=false
bUra=false
bCyt=false
bGua=false
bBz=false
bpNP=false
bCO2H=false
bHSO4=false
bH2PO4=false
bNO2=false
bSH=false
bSCH3=false
bOAc=false
bO=false
bH=false
bF=false
bCl=false
bBr=false
COUNTXH=0
COUNTCH2OH=0
z=$(($N-$H))

for (( i=1; i<=$z; i++ ))
do
  echo "Which chemical group is bonded to the carbon $i OVER the ring plane? (H,OH,CH2OH,F,Cl,Br)"
  read group
  POSIC=$(($POSIC+1))
  cat calc.zmat subs-$group.zmat > trial.zmat
  mv trial.zmat calc.zmat
  sed -i 's/RATOM/'$i'/g' calc.zmat
  if [ $i = $N ]
  then
    sed -i 's/A2/1/g' calc.zmat
  else
    sed -i 's/A2/'$(($i+1))'/g' calc.zmat
  fi
  if [ $i = 1 ]
  then
    sed -i 's/A3/'$N'/g' calc.zmat
  else
    sed -i 's/A3/'$(($i-1))'/g' calc.zmat
  fi
  sed -i 's/POSIC/'$POSIC'/g' calc.zmat
  sed -i 's/UPorDOWN/UP/g' calc.zmat
  if [ $group = "OH" ]
  then
    COUNTXH=$(($COUNTXH+1))
    NUMRAN=$(($NUMRAN+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+1))
    bOH=true
  elif [ $group = "CH3" ]
  then
    POSIC=$(($POSIC+3))
    bCH3=true
    bH=true
  elif [ $group = "OCH3" ]
  then
    COUNTXH=$(($COUNTXH+1))
    NUMRAN=$(($NUMRAN+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    POSIC=$(($POSIC+4))
    bOCH3=true
    bCH3=true
    bOH=true
    bH=true
  elif [ $group = "NH2" ]
  then
    COUNTXH=$(($COUNTXH+1))
    NUMRAN=$(($NUMRAN+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    POSIC=$(($POSIC+2))
    bNH2=true
  elif [ $group = "CH2OH" ]
  then
    COUNTCH2OH=$(($COUNTCH2OH+1))
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.zmat
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    cat calc.var ran-CH2OH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    NUMRAN=$(($NUMRAN+1))
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+4))
    bCH2OH=true
    bH=true
    bOH=true
  elif [ $group = "OAc" ]
  then
    COUNTCH2OH=$(($COUNTCH2OH+1))
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.zmat
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {3..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-CH2OH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    NUMRAN=$(($NUMRAN+1))
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+6))
    bOAc=true
  elif [ $group = "CH2OCH3" ]
  then
    COUNTCH2OH=$(($COUNTCH2OH+1))
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.zmat
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    sed -i 's/POS2/'$(($POSIC+2))'/g' calc.zmat
    cat calc.var ran-CH2OH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    NUMRAN=$(($NUMRAN+1))
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+7))
    bCH2OCH3=true
    bCH2OH=true
    bCH3=true
    bH=true
    bOH=true
  elif [ $group = "NAc" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    sed -i 's/POS2/'$(($POSIC+2))'/g' calc.zmat
    sed -i 's/POS4/'$(($POSIC+4))'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+7))
    bNAc=true
    bCH3=true
    bH=true
  elif [ $group = "Ade" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {11..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+13))
    bAde=true
  elif [ $group = "Thy" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {12..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+13))
    bThy=true
  elif [ $group = "Ura" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {9..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+10))
    bUra=true
  elif [ $group = "Cyt" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {10..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+11))
    bCyt=true
  elif [ $group = "Gua" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {13..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+14))
    bGua=true
  elif [ $group = "Bz" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {9..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+10))
    bBz=true
  elif [ $group = "pNP" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {12..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+13))
    bpNP=true
  elif [ $group = "CO2H" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {2..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+3))
    bCO2H=true
  elif [ $group = "H2PO4" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {4..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+6))
    bH2PO4=true
  elif [ $group = "HSO4" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {4..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+5))
    bHSO4=true
  elif [ $group = "NO2" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+2))
    bNO2=true
  elif [ $group = "SH" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+1))
    bSH=true
  elif [ $group = "SCH3" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+4))
    bSCH3=true
    bH=true
    bCH3=true
  elif [ $group = "C" ]
  then
    POSIC=$(($POSIC-1))
  elif [ $group = "O" ]
  then
    bO=true
  elif [ $group = "H" ]
  then
    bH=true
  elif [ $group = "F" ]
  then
    bF=true
  elif [ $group = "Cl" ]
  then
    bCl=true
  elif [ $group = "Br" ]
  then
    bBr=true
  fi
  echo "Which chemical group is bonded to the carbon $i UNDER the ring plane? (H,OH,CH2OH,F,Cl,Br)"
  read group
  POSIC=$(($POSIC+1))
  cat calc.zmat subs-$group.zmat > trial.zmat
  mv trial.zmat calc.zmat
  sed -i 's/RATOM/'$i'/g' calc.zmat
  if [ $i = $N ]
  then
    sed -i 's/A2/1/g' calc.zmat
  else
    sed -i 's/A2/'$(($i+1))'/g' calc.zmat
  fi
  if [ $i = 1 ]
  then
    sed -i 's/A3/'$N'/g' calc.zmat
  else
    sed -i 's/A3/'$(($i-1))'/g' calc.zmat
  fi
  sed -i 's/POSIC/'$POSIC'/g' calc.zmat
  sed -i 's/UPorDOWN/DOWN/g' calc.zmat
  if [ $group = "OH" ]
  then
    COUNTXH=$(($COUNTXH+1))
    NUMRAN=$(($NUMRAN+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+1))
    bOH=true
  elif [ $group = "CH3" ]
  then
    POSIC=$(($POSIC+3))
    bCH3=true
    bH=true
  elif [ $group = "OCH3" ]
  then
    COUNTXH=$(($COUNTXH+1))
    NUMRAN=$(($NUMRAN+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    POSIC=$(($POSIC+4))
    bOCH3=true
    bCH3=true
    bOH=true
    bH=true
  elif [ $group = "NH2" ]
  then
    COUNTXH=$(($COUNTXH+1))
    NUMRAN=$(($NUMRAN+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    POSIC=$(($POSIC+2))
    bNH2=true
  elif [ $group = "CH2OH" ]
  then
    COUNTCH2OH=$(($COUNTCH2OH+1))
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.zmat
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    cat calc.var ran-CH2OH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    NUMRAN=$(($NUMRAN+1))
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+4))
    bCH2OH=true
    bH=true
    bOH=true
  elif [ $group = "OAc" ]
  then
    COUNTCH2OH=$(($COUNTCH2OH+1))
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.zmat
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {3..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-CH2OH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    NUMRAN=$(($NUMRAN+1))
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+6))
    bOAc=true
  elif [ $group = "CH2OCH3" ]
  then
    COUNTCH2OH=$(($COUNTCH2OH+1))
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.zmat
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    sed -i 's/POS2/'$(($POSIC+2))'/g' calc.zmat
    cat calc.var ran-CH2OH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTCH2OH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    NUMRAN=$(($NUMRAN+1))
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+7))
    bCH2OCH3=true
    bCH2OH=true
    bCH3=true
    bH=true
    bOH=true
  elif [ $group = "NAc" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    sed -i 's/POS2/'$(($POSIC+2))'/g' calc.zmat
    sed -i 's/POS4/'$(($POSIC+4))'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+7))
    bNAc=true
    bCH3=true
    bH=true
  elif [ $group = "Ade" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {11..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+13))
    bAde=true
  elif [ $group = "Thy" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {12..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+13))
    bThy=true
  elif [ $group = "Ura" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {9..1..-1}
    do
      sed -i 's/POS'$i'/'$(($POSIC+$i))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+10))
    bUra=true
  elif [ $group = "Cyt" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {10..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+11))
    bCyt=true
  elif [ $group = "Gua" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {13..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+14))
    bGua=true
  elif [ $group = "Bz" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {9..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+10))
    bBz=true
  elif [ $group = "pNP" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {12..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+13))
    bpNP=true
  elif [ $group = "CO2H" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {2..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+3))
    bCO2H=true
  elif [ $group = "H2PO4" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {4..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+6))
    bH2PO4=true
  elif [ $group = "HSO4" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    for j in {4..1..-1}
    do
      sed -i 's/POS'$j'/'$(($POSIC+$j))'/g' calc.zmat
    done
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+5))
    bHSO4=true
  elif [ $group = "NO2" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+2))
    bNO2=true
  elif [ $group = "SH" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+1))
    bSH=true
  elif [ $group = "SCH3" ]
  then
    NUMRAN=$(($NUMRAN+1))
    COUNTXH=$(($COUNTXH+1))
    sed -i 's/###/'$COUNTXH'/g' calc.zmat
    sed -i 's/POS1/'$(($POSIC+1))'/g' calc.zmat
    cat calc.var ran-XH.var > trial.var
    mv trial.var calc.var
    sed -i 's/AAA/'$COUNTXH'/g' calc.var
    sed -i 's/###/'$NUMRAN'/g' calc.var
    POSIC=$(($POSIC+4))
    bSCH3=true
    bH=true
    bCH3=true
  elif [ $group = "C" ]
  then
    POSIC=$(($POSIC-1))
  elif [ $group = "O" ]
  then
    bO=true
  elif [ $group = "H" ]
  then
    bH=true
  elif [ $group = "F" ]
  then
    bF=true
  elif [ $group = "Cl" ]
  then
    bCl=true
  elif [ $group = "Br" ]
  then
    bBr=true
  fi

done 

if $bOH
then
  cat calc.var subs-OH.var > trial.var
  mv trial.var calc.var
fi

if $bCH3
then
  cat calc.var subs-CH3.var > trial.var
  mv trial.var calc.var
fi

if $bO
then
  cat calc.var subs-O.var > trial.var
  mv trial.var calc.var
fi

if $bNH2
then
  cat calc.var subs-NH2.var > trial.var
  mv trial.var calc.var
fi

if $bNAc
then
  cat calc.var subs-NAc.var > trial.var
  mv trial.var calc.var
fi

if $bAde
then
  cat calc.var subs-Ade.var > trial.var
  mv trial.var calc.var
fi

if $bThy
then
  cat calc.var subs-Thy.var > trial.var
  mv trial.var calc.var
fi

if $bUra
then
  cat calc.var subs-Ura.var > trial.var
  mv trial.var calc.var
fi

if $bCyt
then
  cat calc.var subs-Cyt.var > trial.var
  mv trial.var calc.var
fi

if $bGua
then
  cat calc.var subs-Gua.var > trial.var
  mv trial.var calc.var
fi

if $bBz
then
  cat calc.var subs-Bz.var > trial.var
  mv trial.var calc.var
fi

if $bpNP
then
  cat calc.var subs-pNP.var > trial.var
  mv trial.var calc.var
fi

if $bCO2H
then
  cat calc.var subs-CO2H.var > trial.var
  mv trial.var calc.var
fi

if $bH2PO4
then
  cat calc.var subs-H2PO4.var > trial.var
  mv trial.var calc.var
fi

if $bHSO4
then
  cat calc.var subs-HSO4.var > trial.var
  mv trial.var calc.var
fi

if $bOAc
then
  cat calc.var subs-OAc.var > trial.var
  mv trial.var calc.var
fi

if $bNO2
then
  cat calc.var subs-NO2.var > trial.var
  mv trial.var calc.var
fi

if $bSH
then
  cat calc.var subs-SH.var > trial.var
  mv trial.var calc.var
fi

if $bSCH3
then
  cat calc.var subs-SCH3.var > trial.var
  mv trial.var calc.var
fi

if $bH 
then
  cat calc.var subs-H.var > trial.var
  mv trial.var calc.var
fi

if $bF
then
  cat calc.var subs-F.var > trial.var
  mv trial.var calc.var
fi

if $bCl
then
  cat calc.var subs-Cl.var > trial.var
  mv trial.var calc.var
fi

if $bBr
then
  cat calc.var subs-Br.var > trial.var
  mv trial.var calc.var
fi


cat calc.var UPandDOWN.var > trial.var
mv trial.var calc.var

echo >> calc.zmat
echo >> calc.var
if [ $study = "PUCK" ]
then
  cat calc.head calc.zmat calc.var calc.link puck$N.gic > calc.gjf
  rm calc.zmat calc.var
elif [ $study = "RIGID" ]
then
  cat calc-rig.head calc.zmat calc.var puck$N-rig.gic > calc.gjf
  rm calc.zmat calc.var
else
  cat calc.head calc.zmat calc.var > calc.gjf
fi

echo "How many samples do you want for your conformational study?"
read calc
name2=$name$calc
name=$name2

for (( i=1; i<=$calc ; i++ ))
do
  cp calc.gjf calc$i.gjf
  sed -i 's/NUMBER/'$i'/g' calc$i.gjf
done

if [ $hatom = "N" ] || [ $hatom = "P" ]
then
  cp rangen-$N-NP.f90 newrangen.f90
  sed -i 's/ZZZ/'$(($NUMRAN-$N+2))'/g' newrangen.f90
else
  cp rangen-$N.f90 newrangen.f90
  sed -i 's/ZZZ/'$(($NUMRAN-$N+3))'/g' newrangen.f90
fi

sed -i 's/XXX/'$calc'/g' newrangen.f90
sed -i 's/AAA/'$N'/g' newrangen.f90
if [ $H = 0 ]
then
  sed -i 's/BBB-CCC/'$H'/g' newrangen.f90
else
  sed -i 's/BBB/'$H'/g' newrangen.f90
  sed -i 's/CCC/'$hatom'/g' newrangen.f90
fi

f95 newrangen.f90 -o rangen.x
./rangen.x

sed 's/ITER/'$calc'/g' readnum.bash > newreadnum.bash
sed -i 's/VALUES/'$NUMRAN'/g' newreadnum.bash
chmod +x newreadnum.bash
./newreadnum.bash < ranumbers.dat

if [ $study = "PUCK" ] || [ $study = "NOPUCKG" ] || [ $study = "RIGID" ]
then
   mkdir $name
   for (( i=1; i<=$calc ; i++ ))
   do
     mkdir $name/$i
     mv calc$i.gjf $name/$i/.
     cd $name/$i
     sed -i 's/kkk/calc'$i'/g' calc$i.gjf
## Line to execute Gaussian  ex.   G16 calc$i.gjf 4
     cd $FOLDER
     cp analysis-$N.bash $name/.
     sed -i 's/CALCS/'$calc'/g' $name/analysis-$N.bash
   done
fi

if [ $study = "NOPUCKPDB" ]
then
   mkdir $name
   for (( i=1; i<=$calc ; i++ ))
   do
     mkdir $name/$i
     mv calc$i.gjf $name/$i/.
     cd $name/$i
     babel -igzmat calc$i.gjf -opdb calc$i.pdb
     rm calc$i.gjf
     cd $FOLDER
   done
fi

if [ $study = "NOPUCKXYZ" ]
then
   mkdir $name
   for (( i=1; i<=$calc ; i++ ))
   do
     mkdir $name/$i
     mv calc$i.gjf $name/$i/.
     cd $name/$i
     babel -igzmat calc$i.gjf -oxyz calc$i.xyz
     rm calc$i.gjf
     cd $FOLDER
   done
fi

rm newrangen.f90 newreadnum.bash ranumbers.dat

echo END


