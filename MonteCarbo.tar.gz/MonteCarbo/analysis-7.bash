#!/bin/bash
for i in {1..CALCS}
do
tac $i/calc$i.gjf.out | grep -m 1 "q2" >> q2.dat
tac $i/calc$i.gjf.out | grep -m 1 "q3" >> q3.dat
tac $i/calc$i.gjf.out | grep -m 1 "PHI2" >> PHI2.dat
tac $i/calc$i.gjf.out | grep -m 1 "PHI3" >> PHI3.dat
tac $i/calc$i.gjf.out | grep -m 1 "SCF Done" >> Energy.dat
done
awk '{print $4}' q2.dat > Q2
awk '{print $4}' q3.dat > Q3
awk '{print $4}' PHI2.dat > PHI2
awk '{print $4}' PHI3.dat > PHI3
awk '{print $5}' Energy.dat > ENERGY
paste Q2 Q3 PHI2 PHI3 ENERGY > Results.dat

rm q2.dat q3.dat PHI2.dat PHI3.dat Energy.dat Q2 Q3 PHI2 PHI3 ENERGY
