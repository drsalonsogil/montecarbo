#!/bin/bash
for i in {1..CALCS}
do
tac $i/calc$i.gjf.out | grep -m 1 "q2" >> q2.dat
tac $i/calc$i.gjf.out | grep -m 1 "PHI2" >> PHI2.dat
tac $i/calc$i.gjf.out | grep -m 1 "SCF Done" >> Energy.dat
done
awk '{print $4}' q2.dat > Q2
awk '{print $4}' PHI2.dat > PHI2
awk '{print $5}' Energy.dat > ENERGY
paste Q2 PHI2 ENERGY > Results.dat

rm q2.dat PHI2.dat Energy.dat Q2 PHI2 ENERGY
