#!/bin/bash
for (( v=1; v<=ITER; v++))
do
  for (( w=1; w<=VALUES; w++ ))
  do
    read num
    sed -i 's/RAN'$w'K/'$num'/g' calc$v.gjf
  done
done
