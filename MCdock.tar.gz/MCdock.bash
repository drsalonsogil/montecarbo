#!/bin/bash
FOLDER=${PWD}
echo "Welcome, what is the name of the folder containing the ligands?"
read name
echo "In which format are they? (GOUT, XYZ, PDB)"
read format
echo "What kind of target? (ARABINO-FRUCTO,FUCO,GALACTO,GALNAC-GLCNAC,GLUCO,IDURONIC-SIALIC,MANNO,RHAMNO,XYLO)"
read target

cd $FOLDER/$name

if [ $format = "GOUT" ]
then
  for i in *
  do
    cd $i
    babel -ig03 *.out -opdb ligand$i.pdb
    prepare_ligand -l ligand$i.pdb 
    cd $FOLDER/$name
  done
elif [ $format = "XYZ" ]
then
  for i in *
  do
    cd $i
    babel -ixyz *.xyz -opdb ligand$i.pdb
    prepare_ligand -l ligand$i.pdb
    cd $FOLDER/$name
  done
elif [ $format = "PDB" ]
then
  for i in *
  do
    cd $i
    cp *.pdb ligand$i.pdb2
    prepare_ligand -l ligand$i.pdb2
    cd $FOLDER/$name
  done
fi

for i in *
do
  cp $FOLDER/receptors/$target/config* $FOLDER/$name/$i/.
  cp $FOLDER/receptors/$target/*.pdbqt $FOLDER/$name/$i/.
  cd $FOLDER/$name/$i
  for j in config*
  do
    var1=${j%.*} 
    var2=${var1#config}
    sed -i 's/LIGAND/ligand'$i'.pdbqt/g' $j
    $FOLDER/vina/vina --config $j --out ligand$i-$var2.pdbqt --log ligand$i-$var2.log
  done
  cd $FOLDER/$name
done

